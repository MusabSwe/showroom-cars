namespace Task2
{
    public interface ISunroof
    {
    }
}namespace Task2
{

    interface ISunRoof
    {
        public void toggle();
    }

}