namespace Task2
{
    class Bicycle : Bike
    {
        private string name;

        public string BicycleNameProp { get; set; }

    }
}