namespace Task2
{
    class Van : Car
    {
       
    }

}