﻿namespace ShowRoom.Core
{
    public interface IMove
    {
        public void move(string gear);
    }
}