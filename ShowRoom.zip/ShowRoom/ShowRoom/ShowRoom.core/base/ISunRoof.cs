namespace ShowRoom.Core
{

   public interface ISunRoof
    {
        public void toggle();
      
    }



}