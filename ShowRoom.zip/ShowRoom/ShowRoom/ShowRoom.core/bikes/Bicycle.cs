namespace ShowRoom.Core
{
    class Bicycle : Bike
    {

    }
}